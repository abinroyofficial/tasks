<div class="w3-top w3-bar w3-white w3-padding w3-card w3-wide">
    <a href="/home" class="w3-bar-item w3-button">EMPLOY 365</a>
    <a href="/profile" class="w3-bar-item w3-button"><?php echo e(Auth::user()->name); ?></a>
    <a href="<?php echo e(route('permissions.index')); ?>" class="w3-bar-item w3-button">permissions</a>
    


    <div class="w3-right w3-hide-small">

        <a href="<?php echo e(route('logout')); ?>" class="w3-bar-item w3-button">logout</a>

    </div>
</div><?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/components/nav-superadmin.blade.php ENDPATH**/ ?>