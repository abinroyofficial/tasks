<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>Catering</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
    .image {
        width: 100vw;
        padding: 10px;
        margin: 10px;
        height: 100vh;
        margin-left: 1px;
        object-fit: cover;
    }

    .image_1 {
        width: 100vw;
        padding: 10px;
        margin: 10px;
        height: 400px;
        margin-left: 0;
        object-fit: cover;
    }


    body {
        margin: 0;
        padding: 0;
        font-family: "Times New Roman", serif
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        font-family: serif;
        letter-spacing: 5px
    }
</style>

<body>
<?php if (isset($component)) { $__componentOriginal7fa6ace84b7e8f740bb7ff63444206cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fa6ace84b7e8f740bb7ff63444206cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-superadmin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-superadmin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fa6ace84b7e8f740bb7ff63444206cf)): ?>
<?php $attributes = $__attributesOriginal7fa6ace84b7e8f740bb7ff63444206cf; ?>
<?php unset($__attributesOriginal7fa6ace84b7e8f740bb7ff63444206cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fa6ace84b7e8f740bb7ff63444206cf)): ?>
<?php $component = $__componentOriginal7fa6ace84b7e8f740bb7ff63444206cf; ?>
<?php unset($__componentOriginal7fa6ace84b7e8f740bb7ff63444206cf); ?>
<?php endif; ?>

    
    <br><br><br>




</body>

</html>
<?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/superadmin-dashboard.blade.php ENDPATH**/ ?>