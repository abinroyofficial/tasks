
            <?php $__currentLoopData = $monthly_record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($record->date); ?></td>
                    <td><?php echo e($record->shift); ?></td>
                    <td><?php echo e($record->sign_in); ?></td> 
                    <td><?php echo e($record->sign_out); ?></td>
                    <td><?php echo e($record->total_time); ?></td> 
                    <td><?php echo e($record->attendance_status); ?></td> 
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
<?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/attendence/monthly-attendence.blade.php ENDPATH**/ ?>