<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\laravel\employmanagement\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>