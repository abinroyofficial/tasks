<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Times New Roman", serif;
            letter-spacing: 5px;
            background-color: #f4f6f9;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 90%;
            max-width: 700px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 40px;
            font-family: "Times New Roman", serif;
            letter-spacing: 0px;
            margin-top: 40px;
        }

        h1 {
            text-align: center;
            font-size: 24px;
            margin-bottom: 30px;
            color: #333;
        }

        .detail {
            border-bottom: 1px solid #e1e1e1;
            padding: 15px 0;
            display: flex;
            justify-content: space-between;
        }

        .label {
            font-weight: bold;
            color: #555;
        }

        .value {
            color: #777;
        }

        .button-container {
            text-align: center;
            margin-top: 30px;
        }

        .back-button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #0056b3;
        }

        h2 {
            color: lightblue;
        }
    </style>
</head>

<body>
    <?php if($roles = App\Models\User::where('email', $user->email)->first()->getRoleNames()->implode(', ') == 'manager'): ?>
        <?php if (isset($component)) { $__componentOriginal04a5844aa2c131e98d761afba2131f4a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04a5844aa2c131e98d761afba2131f4a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-manager','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-manager'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04a5844aa2c131e98d761afba2131f4a)): ?>
<?php $attributes = $__attributesOriginal04a5844aa2c131e98d761afba2131f4a; ?>
<?php unset($__attributesOriginal04a5844aa2c131e98d761afba2131f4a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04a5844aa2c131e98d761afba2131f4a)): ?>
<?php $component = $__componentOriginal04a5844aa2c131e98d761afba2131f4a; ?>
<?php unset($__componentOriginal04a5844aa2c131e98d761afba2131f4a); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginal923aede3d077d0d34020dc67d7c70f7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal923aede3d077d0d34020dc67d7c70f7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-user','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal923aede3d077d0d34020dc67d7c70f7c)): ?>
<?php $attributes = $__attributesOriginal923aede3d077d0d34020dc67d7c70f7c; ?>
<?php unset($__attributesOriginal923aede3d077d0d34020dc67d7c70f7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal923aede3d077d0d34020dc67d7c70f7c)): ?>
<?php $component = $__componentOriginal923aede3d077d0d34020dc67d7c70f7c; ?>
<?php unset($__componentOriginal923aede3d077d0d34020dc67d7c70f7c); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php $__currentLoopData = $leave_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <h2>LEAVE BALANCE</h2>
            <div class="detail">
                <span hidden class="value"><?php echo e($data->user_id); ?></span>
            </div>
            <div class="detail">
                <span class="label">year:</span>
                <span class="value"><?php echo e($data->year); ?></span>
            </div>
            <div class="detail">
                <span class="label">casual leave:</span>
                <span class="value"><?php echo e($data->casual_leave); ?></span>
            </div>
            <div class="detail">
                <span class="label">sick leave</span>
                <span class="value"><?php echo e($data->sick_leave); ?></span>
            </div>
            <div class="detail">
                <span class="label">Earned leave</span>
                <span class="value"><?php echo e($data->earned_leave); ?></span>
            </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>

</html>
<?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/userLeave/view.blade.php ENDPATH**/ ?>