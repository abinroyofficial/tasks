<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Permissions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <?php echo $__env->make('role-permission.nav-links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <?php if(session('status-delete')): ?>
        <div class="alert alert-danger"><?php echo e(session('status-delete')); ?></div>
    <?php endif; ?>
    <div class="container mt-5">
        <h1 class="mb-4">Permissions</h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create permission')): ?>
            <a href="<?php echo e(url('permissions/create')); ?>" class="btn btn-primary mb-3">Add Permission</a>
        <?php endif; ?>



        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Guard Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></< /td>
                        <td><?php echo e($item->guard_name); ?></< /td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit permission')): ?>
                                <a href="<?php echo e(url('permissions/' . $item->id . '/edit')); ?>"
                                    class="btn btn-success  mx-2">edit</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete permission')): ?>
                                <a href="<?php echo e(url('permissions/' . $item->id . '/delete')); ?>"
                                    class="btn btn-danger  mx-2">delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/role-permission/permission/one.blade.php ENDPATH**/ ?>