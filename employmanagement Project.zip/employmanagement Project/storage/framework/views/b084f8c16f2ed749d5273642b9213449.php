<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
        body {
            font-family: "Times New Roman", serif;
            letter-spacing:0px;

        }
    </style>
</head>

<body>
    <?php if (isset($component)) { $__componentOriginal23adf423b8d50e250ca63c3291ff5404 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23adf423b8d50e250ca63c3291ff5404 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-attendence','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-attendence'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23adf423b8d50e250ca63c3291ff5404)): ?>
<?php $attributes = $__attributesOriginal23adf423b8d50e250ca63c3291ff5404; ?>
<?php unset($__attributesOriginal23adf423b8d50e250ca63c3291ff5404); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23adf423b8d50e250ca63c3291ff5404)): ?>
<?php $component = $__componentOriginal23adf423b8d50e250ca63c3291ff5404; ?>
<?php unset($__componentOriginal23adf423b8d50e250ca63c3291ff5404); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/attendence/attendence-request.blade.php ENDPATH**/ ?>