<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <?php echo $__env->make('role-permission.nav-links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <?php if(session('status-delete')): ?>
        <div class="alert alert-danger"><?php echo e(session('status-delete')); ?></div>
    <?php endif; ?>
    <div class="container mt-5">
        <h1 class="mb-4">users</h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create user')): ?>
            <a href="<?php echo e(url('users/create')); ?>" class="btn btn-primary mb-3">Add users</a>
        <?php endif; ?>



        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>roles</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <?php if(!empty($user->getRoleNames())): ?>
                                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rolename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="badge bg-secondary mx-2"><?php echo e($rolename); ?></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>

                        <td>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit user')): ?>
                                <a href="<?php echo e(url('users/' . $user->id . '/edit')); ?>" class="btn btn-success  mx-2">edit</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete user')): ?>
                                <a href="<?php echo e(url('users/' . $user->id . '/delete')); ?>"
                                    class="btn btn-danger  mx-2">delete</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update user biodata')): ?>
                                <?php if(empty(App\Models\Manager::where('user_id', $user->id)->first())): ?>
                                    <a href="<?php echo e(url('updateinfo/' . $user->id)); ?>" class="btn btn-warning mx-2">Add
                                        Info</a>
                                <?php else: ?>
                                    <span>user data updated</span>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add user leave')): ?>
                                <?php if(empty(App\Models\UserLeave::where('user_id', $user->id)->where('year',\Carbon\Carbon::today()->year)->first())): ?>
                                    <a href="<?php echo e(url('addleaveData/' . $user->id)); ?>" class="btn btn-primary mx-2">Add
                                        Leave Data</a>
                                <?php else: ?>
                                    <span>done</span>
                                <?php endif; ?>
                            <?php endif; ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/role-permission/users/one.blade.php ENDPATH**/ ?>