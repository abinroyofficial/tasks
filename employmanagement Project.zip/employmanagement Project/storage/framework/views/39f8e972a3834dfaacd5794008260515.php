<div class="w3-top w3-bar w3-white w3-padding w3-card w3-wide">
    <a href="/home" class="w3-bar-item w3-button">EMPLOY 365</a>


    <div class="w3-right w3-hide-small">
        
        
        
        <a href="/my-team-requests/<?php echo e(Auth::user()->id); ?>" class="w3-bar-item w3-button">leave request</a>
        <a href="/my-team-requests-wfh/<?php echo e(Auth::user()->id); ?>" class="w3-bar-item w3-button">work from home </a>
        <a href="/my-team-requests-regulisation/<?php echo e(Auth::user()->id); ?>" class="w3-bar-item w3-button">regulization</a>
        <?php if(
            $roles =
                App\Models\User::where('id', Auth::user()->id)->first()->getRoleNames()->implode(', ') == 'manager'): ?>
            <a href="<?php echo e(route('manager-dashboard')); ?>" class="w3-bar-item w3-button">back</a>
        <?php else: ?>
        <a href="<?php echo e(route('dashboard')); ?>" class="w3-bar-item w3-button">back</a>
        <?php endif; ?>
        
        
    </div>
</div><?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/components/nav-manager-request.blade.php ENDPATH**/ ?>