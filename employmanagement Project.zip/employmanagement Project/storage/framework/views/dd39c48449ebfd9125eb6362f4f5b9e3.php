<div class="w3-top w3-bar w3-white w3-padding w3-card w3-wide">
    <a href="/home" class="w3-bar-item w3-button">EMPLOY 365</a>


    <div class="w3-right w3-hide-small">
        
        <a href="" class="w3-bar-item w3-button">Tasks</a>
        <a href="" class="w3-bar-item w3-button">salary</a>
        <a href="/attendence-request" class="w3-bar-item w3-button">attendence request</a>
        <a href="/attendence/<?php echo e(Auth::user()->id); ?>" class="w3-bar-item w3-button">attendence</a>
        <a href="/view-profile/<?php echo e(Auth::user()->id); ?>" class="w3-bar-item w3-button">Profile</a>

        <a href="<?php echo e(route('logout')); ?>" class="w3-bar-item w3-button">logout</a>
        <a href="/profile" class="w3-bar-item w3-button"><?php echo e(Auth::user()->name); ?></a>
    </div>
</div><?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/components/nav-user.blade.php ENDPATH**/ ?>