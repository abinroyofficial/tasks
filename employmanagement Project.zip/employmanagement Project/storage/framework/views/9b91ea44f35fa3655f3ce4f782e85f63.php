
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Permission</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Create role</h1>

        
        <form action="<?php echo e(route('roles.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            
            <button type="submit" class="btn btn-success">Create roles</button>
        </form>

        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary mt-3">Back to Permissions List</a>
    </div>
</body>
</html>
<?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/role-permission/roles/create.blade.php ENDPATH**/ ?>