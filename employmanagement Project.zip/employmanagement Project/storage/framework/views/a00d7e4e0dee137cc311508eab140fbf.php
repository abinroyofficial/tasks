<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <?php echo $__env->make('role-permission.nav-links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <?php if(session('status-delete')): ?>
        
        <div class="alert alert-danger"><?php echo e(session('status-delete')); ?></div>
        
    <?php endif; ?>
    <div class="container mt-5">
        <h1 class="mb-4">users</h1>

        <a href="<?php echo e(url('manager/create')); ?>" class="btn btn-primary mb-3">Add manager</a>


        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>roles</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($manager->id); ?></td>
                        <td><?php echo e($manager->name); ?></td>
                        <td><?php echo e($manager->email); ?></td>
                        <td>
                            <?php if(!empty($manager->getRoleNames())): ?>
                            <?php $__currentLoopData = $manager->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rolename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="badge bg-secondary mx-2"><?php echo e($rolename); ?></label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        
                        <td>
                            
                            <a href="<?php echo e(url('manager/' . $manager->id . '/edit')); ?>" class="btn btn-success  mx-2">edit</a>
                            <a href="<?php echo e(url('manager/' . $manager->id . '/delete')); ?>" class="btn btn-danger  mx-2">delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/role-permission/manager/one.blade.php ENDPATH**/ ?>