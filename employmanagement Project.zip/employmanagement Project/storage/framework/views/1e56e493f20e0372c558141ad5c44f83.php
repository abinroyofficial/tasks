<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Today's Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            font-family: "Times New Roman", serif;

        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 10px;
            text-align: left;

        }

        th {

            position: relative;
        }

        th.sortable {
            cursor: pointer;
        }

        th.sortable:hover {
            background-color: #eaeaea;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>

<body>
    <?php if(
        $roles =
            App\Models\User::where('id', Auth::user()->id)->first()->getRoleNames()->implode(', ') == 'manager'): ?>
        <?php if (isset($component)) { $__componentOriginal04a5844aa2c131e98d761afba2131f4a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04a5844aa2c131e98d761afba2131f4a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-manager','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-manager'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04a5844aa2c131e98d761afba2131f4a)): ?>
<?php $attributes = $__attributesOriginal04a5844aa2c131e98d761afba2131f4a; ?>
<?php unset($__attributesOriginal04a5844aa2c131e98d761afba2131f4a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04a5844aa2c131e98d761afba2131f4a)): ?>
<?php $component = $__componentOriginal04a5844aa2c131e98d761afba2131f4a; ?>
<?php unset($__componentOriginal04a5844aa2c131e98d761afba2131f4a); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginal923aede3d077d0d34020dc67d7c70f7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal923aede3d077d0d34020dc67d7c70f7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-user','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal923aede3d077d0d34020dc67d7c70f7c)): ?>
<?php $attributes = $__attributesOriginal923aede3d077d0d34020dc67d7c70f7c; ?>
<?php unset($__attributesOriginal923aede3d077d0d34020dc67d7c70f7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal923aede3d077d0d34020dc67d7c70f7c)): ?>
<?php $component = $__componentOriginal923aede3d077d0d34020dc67d7c70f7c; ?>
<?php unset($__componentOriginal923aede3d077d0d34020dc67d7c70f7c); ?>
<?php endif; ?>
    <?php endif; ?>

    <div class="container" style="margin-top: 80px;">
        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                data-bs-toggle="dropdown" aria-expanded="false">
                Monthly Attendance
            </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                <li><a class="dropdown-item" value="march">March 2025</a></li>
                <li><a class="dropdown-item" value="April">April 2025</a></li>
                <li><a class="dropdown-item" value="May">May 2025</a></li>
                <li><a class="dropdown-item" value="June">June 2025</a></li>
                <li><a class="dropdown-item" value="July">July 2025</a></li>
                <li><a class="dropdown-item" value="August">August 2025</a></li>
                <li><a class="dropdown-item" value="September">September 2025</a></li>
                <li><a class="dropdown-item" value="October">October 2025</a></li>
                <li><a class="dropdown-item" value="November">November 2025</a></li>
                <li><a class="dropdown-item" value="December">December 2025</a></li>
            </ul>
        </div>

        <form action="" id="attendence_form">
            <?php echo csrf_field(); ?>
            <h2 class="mt-5">Mark Today's Attendance</h2>
            <div class="mb-3">
                <label for="Date" class="form-label">Date</label>
                <p name="date" id="date" value=""><?php echo e(\Carbon\Carbon::today()->toDateString()); ?></p>
            </div>
            <?php
                $attendance = App\Models\Attendence::where('user_id', Auth::user()->id)
                    ->where('date', \Carbon\Carbon::today()->toDateString())
                    ->first();
            ?>

            <?php if($attendance): ?>

                <?php if($attendance->sign_out): ?>
                    <span>recored added successfully</span>
                <?php else: ?>
                    <button type="button" class="btn btn-primary" id="sign_in_button" disabled>Sign In</button>
                    <button type="button" class="btn btn-success" id="sign_out_button">Sign Out</button>
                    <div class="mt-3">
                        <button type="button" id="submit_button" class="btn btn-success">Submit Attendance</button>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <button type="button" class="btn btn-primary" id="sign_in_button">Sign In</button>
                <button type="button" class="btn btn-success" id="sign_out_button" disabled>Sign Out</button>
                <div class="mt-3">
                    <button type="button" id="submit_button" class="btn btn-success">Submit Attendance</button>
                </div>
            <?php endif; ?>





            <input type="hidden" id="user_id" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
            <input type="hidden" id="date" name="date" value="<?php echo e(\Carbon\Carbon::today()->toDateString()); ?>">
            <input type="hidden" id="sign_in" name="sign_in" value="">
            <input type="hidden" id="sign_out" name="sign_out" value="">
            <input type="hidden" id="shift" name="shift"
                value="<?php echo e($data->work_time_from); ?>-<?php echo e($data->work_time_to); ?>">

    </div>
    </form>

    <table class="table table-bordered">
        <thead style="background-color: grey;color:white">
            <tr>
                <th>DATE</th>
                <th>SHIFT</th>
                <th>IN</th>
                <th>OUT</th>
                <th>TOTAL TIME</th>
                <th>STATUS</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $monthly_record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($record->date); ?></td>
                    <td><?php echo e($record->shift); ?></td>
                    <td><?php echo e($record->sign_in); ?></td>
                    <td><?php echo e($record->sign_out); ?></td>
                    <td><?php echo e($record->total_time); ?></td>
                    <td><?php echo e($record->attendance_status); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>




</body>
<script>
    $(document).ready(function() {
        var signInTime = null;
        var signOutTime = null;


        $('#sign_in_button').click(function() {
            signInTime = moment().format('HH:mm:ss');
            $('#sign_in').val(signInTime);
            $('#sign_in_button').prop('disabled', true);
            $('#sign_out_button').prop('disabled', false);
        });


        $('#sign_out_button').click(function() {
            signOutTime = moment().format('HH:mm:ss');
            $('#sign_out').val(signOutTime);
            $('#sign_out_button').prop('disabled', true);
            $('#sign_in_button').prop('disabled', false);


        });
        $('#submit_button').click(function() {
            $.ajax({
                url: '/attendance-store',
                method: 'POST',
                data: $('#attendence_form').serialize(),
                success: function(response) {
                    alert(response.message);
                    location.reload();

                    
                },
                
            });
        });



        



        $(".dropdown-item").click(function() {
            var month = $(this).attr("value");

            $.ajax({
                url: '/attendance-monthly',
                method: 'GET',
                data: {
                    month: month,
                    id: <?php echo e(Auth::user()->id); ?>,
                },
                success: function(response) {

                    $("table tbody").html(response);




                }

            })
        })


    });
</script>

</html>
<?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/attendence/index.blade.php ENDPATH**/ ?>