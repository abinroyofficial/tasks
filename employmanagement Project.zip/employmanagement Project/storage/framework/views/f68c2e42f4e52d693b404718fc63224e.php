<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Times New Roman", serif
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-family: serif;
            letter-spacing: 5px
        }

        .body {
            margin-top: 50px;
        }
    </style>
</head>
<?php if($roles = App\Models\User::where('email', $user->email)->first()->getRoleNames()->implode(', ') == 'manager'): ?>
    <?php if (isset($component)) { $__componentOriginal04a5844aa2c131e98d761afba2131f4a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04a5844aa2c131e98d761afba2131f4a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-manager','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-manager'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04a5844aa2c131e98d761afba2131f4a)): ?>
<?php $attributes = $__attributesOriginal04a5844aa2c131e98d761afba2131f4a; ?>
<?php unset($__attributesOriginal04a5844aa2c131e98d761afba2131f4a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04a5844aa2c131e98d761afba2131f4a)): ?>
<?php $component = $__componentOriginal04a5844aa2c131e98d761afba2131f4a; ?>
<?php unset($__componentOriginal04a5844aa2c131e98d761afba2131f4a); ?>
<?php endif; ?>
    <?php elseif($roles = App\Models\User::where('email', $user->email)->first()->getRoleNames()->implode(', ') == 'user'): ?>
        <?php if (isset($component)) { $__componentOriginal923aede3d077d0d34020dc67d7c70f7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal923aede3d077d0d34020dc67d7c70f7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-user','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal923aede3d077d0d34020dc67d7c70f7c)): ?>
<?php $attributes = $__attributesOriginal923aede3d077d0d34020dc67d7c70f7c; ?>
<?php unset($__attributesOriginal923aede3d077d0d34020dc67d7c70f7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal923aede3d077d0d34020dc67d7c70f7c)): ?>
<?php $component = $__componentOriginal923aede3d077d0d34020dc67d7c70f7c; ?>
<?php unset($__componentOriginal923aede3d077d0d34020dc67d7c70f7c); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginal7fa6ace84b7e8f740bb7ff63444206cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fa6ace84b7e8f740bb7ff63444206cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-superadmin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-superadmin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fa6ace84b7e8f740bb7ff63444206cf)): ?>
<?php $attributes = $__attributesOriginal7fa6ace84b7e8f740bb7ff63444206cf; ?>
<?php unset($__attributesOriginal7fa6ace84b7e8f740bb7ff63444206cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fa6ace84b7e8f740bb7ff63444206cf)): ?>
<?php $component = $__componentOriginal7fa6ace84b7e8f740bb7ff63444206cf; ?>
<?php unset($__componentOriginal7fa6ace84b7e8f740bb7ff63444206cf); ?>
<?php endif; ?>

    <?php endif; ?>

    <body class="body">

         <?php $__env->slot('header', null, []); ?> 
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Profile')); ?>

            </h2>
         <?php $__env->endSlot(); ?>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
                <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                    <div class="max-w-xl">
                        <?php echo $__env->make('profile.partials.update-profile-information-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>


                <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                    <div class="max-w-xl">
                        <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>


                <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                    <div class="max-w-xl">
                        <?php echo $__env->make('profile.partials.delete-user-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>
        </div>

    </body>

</html>
<?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/profile/edit.blade.php ENDPATH**/ ?>