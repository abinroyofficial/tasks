<div>
    <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-primary mx-2 mt-5">Permissions</a>
    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-success mx-2 mt-5">roles</a>
    <a href="<?php echo e(url('users')); ?>" class="btn btn-warning mx-2 mt-5">users</a>
    
</div><?php /**PATH C:\wamp64\www\laravel\employmanagement\resources\views/role-permission/nav-links.blade.php ENDPATH**/ ?>