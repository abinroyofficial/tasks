<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>Catering</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
    .image {
        width: 100vw;
        padding: 10px;
        margin: 10px;
        height: 100vh;
        margin-left: 1px;
        object-fit: cover;
    }

    .image_1 {
        width: 100vw;
        padding: 10px;
        margin: 10px;
        height: 400px;
        margin-left: 0;
        object-fit: cover;
    }


    body {
        margin: 0;
        padding: 0;
        font-family: "Times New Roman", serif
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        font-family: serif;
        letter-spacing: 5px
    }
</style>

<body>


    <div class="w3-top w3-bar w3-white w3-padding w3-card w3-wide">
        <a href="/home" class="w3-bar-item w3-button">EMPLOY 365</a>


        <div class="w3-right w3-hide-small">
            <a href="" class="w3-bar-item w3-button">About</a>
            <a href="" class="w3-bar-item w3-button">Menu</a>
            <a href="{{route('logout')}}" class="w3-bar-item w3-button">logout</a>
            <a href="/profile" class="w3-bar-item w3-button">{{ Auth::user()->name }}</a>
        </div>
    </div>

    <div id="home" class="w3-content">



        <!-- About -->
        <div id="about" class="w3-padding-top-64">
            <div class="w3-row">

                <div class="w3-half w3-padding-large w3-hide-small">

                </div>

                <div class="w3-half w3-padding-large">
                    <h1 class="w3-center">E L & N </h1><br>
                    <h5 class="w3-center">Tradition since 1889</h5>
                    <p class="w3-large">
                        The Catering was founded in blabla by Mr. Smith in lorem ipsum dolor sit amet, consectetur
                        adipiscing elit consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua.</p>
                    <p class="w3-large w3-text-grey w3-hide-medium">
                        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim
                        id est laborum consectetur adipiscing elit, sed do eiusmod temporincididunt ut labore et dolore
                        magna aliqua.</p>
                </div>

            </div>
        </div>



    </div>
</body>

</html>
