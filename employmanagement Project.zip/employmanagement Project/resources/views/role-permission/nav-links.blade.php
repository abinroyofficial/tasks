<div>
    <a href="{{route('permissions.index')}}" class="btn btn-primary mx-2 mt-5">Permissions</a>
    <a href="{{route('roles.index')}}" class="btn btn-success mx-2 mt-5">roles</a>
    <a href="{{url('users')}}" class="btn btn-warning mx-2 mt-5">users</a>
    
</div>