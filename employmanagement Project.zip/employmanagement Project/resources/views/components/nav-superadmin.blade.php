<div class="w3-top w3-bar w3-white w3-padding w3-card w3-wide">
    <a href="/home" class="w3-bar-item w3-button">EMPLOY 365</a>
    <a href="/profile" class="w3-bar-item w3-button">{{ Auth::user()->name }}</a>
    <a href="{{ route('permissions.index') }}" class="w3-bar-item w3-button">permissions</a>
    


    <div class="w3-right w3-hide-small">

        <a href="{{ route('logout') }}" class="w3-bar-item w3-button">logout</a>

    </div>
</div>