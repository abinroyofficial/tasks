
<div class="w3-top w3-bar w3-white w3-padding w3-card w3-wide">
    
    <a href="/home" class="w3-bar-item w3-button">EMPLOY 365</a>
    <div class="w3-right w3-hide-small">
       <a href="/nav-home" class="w3-bar-item w3-button">Home</a>
       <a href="/nav-about" class="w3-bar-item w3-button">About</a>
       <a href="/nav-contact" class="w3-bar-item w3-button">Contact</a>
       <a href="{{route('register')}}" class="w3-bar-item w3-button">Registration</a>
       <a href="{{route('login')}}" class="w3-bar-item w3-button">Login</a>
    </div>
 </div>
