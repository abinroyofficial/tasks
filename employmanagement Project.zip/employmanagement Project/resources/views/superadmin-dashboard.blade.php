<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>Catering</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
    .image {
        width: 100vw;
        padding: 10px;
        margin: 10px;
        height: 100vh;
        margin-left: 1px;
        object-fit: cover;
    }

    .image_1 {
        width: 100vw;
        padding: 10px;
        margin: 10px;
        height: 400px;
        margin-left: 0;
        object-fit: cover;
    }


    body {
        margin: 0;
        padding: 0;
        font-family: "Times New Roman", serif
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        font-family: serif;
        letter-spacing: 5px
    }
</style>

<body>
<x-nav-superadmin></x-nav-superadmin>

    
    <br><br><br>




</body>

</html>
