<?php

use App\Http\Controllers\AttendenceController;
use App\Http\Controllers\LeaveController;
use App\Http\Controllers\ManagerController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RegulizationController;
use App\Http\Controllers\RequestController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UserLeaveController;
use App\Http\Controllers\WorkFromHomeController;
use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');


Route::get('/employ-dashboard', function () {
    return view('employ-dashboard');
})->middleware(['auth', 'verified'])->name('employ-dashboard');

Route::get('/superadmin-dashboard', function () {
    return view('superadmin-dashboard');
})->middleware(['auth', 'verified'])->name('superadmin-dashboard');

Route::get('/manager-dashboard', function () {
    return view('manager-dashboard');
})->middleware(['auth', 'verified'])->name('manager-dashboard');


Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

Route::group(['middleware' => ['role:super admin|employ|manager|senior manager']],function(){
    Route::resource('permissions',PermissionController::class);
    Route::get('permissions/{id}/delete', [PermissionController::class, 'destroy'])->middleware('permission:delete');
    
    
    Route::resource('roles',RoleController::class);
    Route::get('roles/{id}/delete', [RoleController::class, 'destroy'])->middleware('permission:delete');
    Route::get('roles/{id}/give-permissions', [RoleController::class, 'addPermissionToRole']);
    Route::put('roles/{id}/give-permissions', [RoleController::class, 'givePermissionToRole']);
    
    
    Route::resource('users',UserController::class);
    Route::get('users/{id}/delete', [UserController::class, 'destroy']);
    Route::get('updateinfo/{id}', [ManagerController::class, 'updateinfo']);
    Route::get('addleaveData/{id}', [UserLeaveController::class, 'index']);
    Route::post('store-leave', [UserLeaveController::class, 'store']);
    Route::post('/store-info',[ManagerController::class,'store'])->name('store-info');

    
});


Route::group(['middleware' => ['role:super admin|employ|manager|senior manager']],function(){

Route::get('/view-profile/{id}',[ManagerController::class,'viewprofile']);

Route::get('/attendence/{id}',[AttendenceController::class,'index'])->name('attendence');
Route::post('/attendance-store',[AttendenceController::class,'store'])->name('attendence-store');
Route::get('/attendance-monthly',[AttendenceController::class,'show'])->name('attendence-monthly');
Route::get('/attendence-request',[AttendenceController::class,'attendenceRequest'])->name('attendence-request');

Route::get('/leave/{id}',[LeaveController::class,'index'])->name('leave');
Route::post('/leave',[LeaveController::class,'store'])->name('leave-store');
Route::get('/show-request/{id}',[LeaveController::class,'show'])->name('show-request');


Route::get('/cancel-request',[RequestController::class,'cancel'])->name('cancel-request');

Route::get('/wfh/{id}',[WorkFromHomeController::class,'index'])->name('wfh');
Route::post('/wfh',[WorkFromHomeController::class,'store'])->name('wfh-store');

Route::get('/regulization/{id}',[RegulizationController::class,'index'])->name('regulization');
Route::get('/regulizaion-store',[RegulizationController::class,'store'])->name('regulizaion-store');

Route::get('/leave-balance/{id}',[UserLeaveController::class,'show'])->name('leave-balance');

});

Route::group(['middleware' => ['role:manager|senior manager']],function(){
Route::get('/my-team/{id}',[ManagerController::class,'myteam'])->name('my-team');
Route::get('/my-team-requests/{id}',[RequestController::class,'index'])->name('show-team-request');
Route::get('/my-team-requests-wfh/{id}',[RequestController::class,'show'])->name('show-team-request');
Route::get('/my-team-requests-regulisation/{id}',[RequestController::class,'regulizationRequest'])->name('show-team-request');
Route::get('/update-leaveRequest',[RequestController::class,'update'])->name('update-leaveRequest');
Route::get('/approve-regulization',[RequestController::class,'approve'])->name('approve-regulization');
});














