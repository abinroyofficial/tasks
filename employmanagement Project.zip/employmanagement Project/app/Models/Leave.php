<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Leave extends Model
{
    protected $fillable = [


        'user_id',
        'supervisor',
        'apply_date',
        'type',
        'from_date',
        'to_date',
        'session',
        'reason',
        'remarks',
        'total'
    ];
}
