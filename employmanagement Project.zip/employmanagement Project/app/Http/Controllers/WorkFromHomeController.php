<?php

namespace App\Http\Controllers;

use App\Models\Manager;
use App\Models\Workfromhome;
use Carbon\Carbon;
use Illuminate\Http\Request;

class WorkFromHomeController extends Controller
{
    public function index($id)
    {

        $data = Manager::where('user_id', $id)->first();

        return view('wfh.wfh-request', compact('data'));
    }


    public function store(Request $request)
    {


        $request->validate([
            'user_id' => 'required|exists:users,id',
            'supervisor' => 'required',
            'type' => 'required|string',
            'from_date' => 'required|date',
            'to_date' => 'required|date',
            'session' => 'required|string',
            'reason' => 'required|string',
            'remarks' => 'nullable|string',
        ]);
       


        $fromDate = Carbon::parse($request->from_date);
        $toDate = Carbon::parse($request->to_date);

        if ($fromDate == $toDate) {

            if ($request->session == "HALF DAY") {

                $totalDays = 0.5;
            }
        } else {
            $totalDays = 1.0;
        }

        $totalDays = $fromDate->diffInDays($toDate) + 1;


        Workfromhome::create([
            'user_id' => $request->user_id,
            'supervisor' => $request->supervisor,
            'apply_date' => $request->date,
            'type' => $request->type,
            'from_date' => $request->from_date,
            'to_date' => $request->to_date,
            'session' => $request->session,
            'total' => $totalDays,
            'reason' => $request->reason,
            'remarks' => $request->remarks,

        ]);
        return redirect()->route('show-request', ['id' => $request->user_id]);
    }
}
