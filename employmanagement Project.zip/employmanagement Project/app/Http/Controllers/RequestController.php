<?php

namespace App\Http\Controllers;

use App\Models\Attendence;
use App\Models\Leave;
use App\Models\Regulization;
use App\Models\User;
use App\Models\UserLeave;
use App\Models\Workfromhome;
use Illuminate\Http\Request;

class RequestController extends Controller
{

    public function index($id)
    {

        $leave_data = Leave::where('supervisor', $id)->orderBy('created_at', 'desc')->get();
        if ($leave_data->isNotEmpty()) {
            $userNames = [];

            foreach ($leave_data as $member) {
                $user = User::find($member->user_id);
                $userNames[$member->user_id] = $user->name;
            }
            return view('requests.index', compact('leave_data', 'userNames'));
        }
    }
    public function show($id)
    {

        $wfh_data = Workfromhome::where('supervisor', $id)->orderBy('created_at', 'desc')->get();
        if ($wfh_data->isNotEmpty()) {

            $userNames = [];
            foreach ($wfh_data as $member) {
                $user = User::find($member->user_id);
                $userNames[$member->user_id] = $user->name;
            }
            return view('requests.wfh_request', compact('wfh_data', 'userNames'));
        }
    }
    public function regulizationRequest($id)
    {

        $reg_data = Regulization::where('supervisor', $id)->orderBy('created_at', 'desc')->get();
        if ($reg_data->isNotEmpty()) {


            $userNames = [];
            foreach ($reg_data as $member) {
                $user = User::find($member->user_id);
                $userNames[$member->user_id] = $user->name;
            }
            return view('requests.reg_request', compact('reg_data', 'userNames'));
        }
    }


    public function update(Request $request)
    {
        $user_id = $request->input('user_id');
        $from_date = $request->input('from_date');
        $To_date = $request->input('To_date');
        $type = $request->input('type');
        $total = $request->input('total');




        if ($type == 'WFH') {
            if ($from_date != $To_date) {
                $attendance_records = Attendence::where('user_id', $user_id)
                    ->whereBetween('date', [$from_date, $To_date])
                    ->get();
                foreach ($attendance_records as $record) {
                    $record->attendance_status = $type;
                    $record->save();
                    $leave_status = Workfromhome::where('user_id', $user_id)->where('from_date', $from_date)->first();
                    $leave_status->status = "approved";
                    $leave_status->save();
                }
            } else {


                $row = Attendence::where('user_id', $user_id)->where('date', $from_date)->first();
                if ($row && $type) {
                    $row->attendance_status = $type;
                    $row->save();
                    $leave_status = Workfromhome::where('user_id', $user_id)->where('from_date', $from_date)->first();
                    $leave_status->status = "approved";
                    $leave_status->save();
                }
            }
        } else {

            if ($from_date != $To_date) {
                $attendance_records = Attendence::where('user_id', $user_id)
                    ->whereBetween('date', [$from_date, $To_date])
                    ->get();
                if ($type == "Casual Leave") {
                    foreach ($attendance_records as $record) {
                        $record->attendance_status = $type;
                        $record->save();
                    }
                    $leave_status = Leave::where('user_id', $user_id)->where('from_date', $from_date)->first();
                    $leave_status->status = "approved";
                    $leave_status->save();

                    if ($leave_status->status = "approved") {
                        $leave_balance = UserLeave::where('user_id', $user_id)->first();
                        $leave_balance->casual_leave = $leave_balance->casual_leave - $total;
                        $leave_balance->save();
                    }
                }
                if ($type == "Sick Leave") {
                    foreach ($attendance_records as $record) {
                        $record->attendance_status = $type;
                        $record->save();
                    }
                    $leave_status = Leave::where('user_id', $user_id)->where('from_date', $from_date)->first();
                    $leave_status->status = "approved";
                    $leave_status->save();

                    if ($leave_status->status = "approved") {
                        $leave_balance = UserLeave::where('user_id', $user_id)->first();
                        $leave_balance->sick_leave = $leave_balance->sick_leave - $total;
                        $leave_balance->save();
                    }
                }
                if ($type == "Earned Leave") {
                    foreach ($attendance_records as $record) {
                        $record->attendance_status = $type;
                        $record->save();
                    }
                    $leave_status = Leave::where('user_id', $user_id)->where('from_date', $from_date)->first();
                    $leave_status->status = "approved";
                    $leave_status->save();

                    if ($leave_status->status = "approved") {
                        $leave_balance = UserLeave::where('user_id', $user_id)->first();
                        $leave_balance->earned_leave = $leave_balance->earned_leave - $total;
                        $leave_balance->save();
                    }
                } else {
                    foreach ($attendance_records as $record) {
                        $record->attendance_status = $type;
                        $record->save();
                        $leave_status = Leave::where('user_id', $user_id)->where('from_date', $from_date)->first();
                        $leave_status->status = "approved";
                        $leave_status->save();
                    }
                }
            } else {


                $row = Attendence::where('user_id', $user_id)->where('date', $from_date)->first();
                if ($row && $type) {
                    if ($type == "Casual Leave") {

                        $row->attendance_status = $type;
                        $row->save();
                        $leave_status = Leave::where('user_id', $user_id)->where('from_date', $from_date)->first();
                        $leave_status->status = "approved";
                        $leave_status->save();
                        if ($leave_status->status = "approved") {
                            $leave_balance = UserLeave::where('user_id', $user_id)->first();
                            $leave_balance->casual_leave = $leave_balance->casual_leave - $total;
                            $leave_balance->save();
                        }

                        return true;
                    }
                    if ($type == "Sick Leave") {

                        $row->attendance_status = $type;
                        $row->save();
                        $leave_status = Leave::where('user_id', $user_id)->where('from_date', $from_date)->first();
                        $leave_status->status = "approved";
                        $leave_status->save();
                        if ($leave_status->status = "approved") {
                            $leave_balance = UserLeave::where('user_id', $user_id)->first();
                            $leave_balance->sick_leave = $leave_balance->sick_leave - $total;
                            $leave_balance->save();
                        }

                        return true;
                    }
                    if ($type == "Earned Leave") {

                        $row->attendance_status = $type;
                        $row->save();
                        $leave_status = Leave::where('user_id', $user_id)->where('from_date', $from_date)->first();
                        $leave_status->status = "approved";
                        $leave_status->save();
                        if ($leave_status->status = "approved") {
                            $leave_balance = UserLeave::where('user_id', $user_id)->first();
                            $leave_balance->earned_leave = $leave_balance->earned_leave - $total;
                            $leave_balance->save();
                        }

                        return true;
                    } else {
                        $row->attendance_status = $type;
                        $row->save();
                        $leave_status = Leave::where('user_id', $user_id)->where('from_date', $from_date)->first();
                        $leave_status->status = "approved";
                        $leave_status->save();
                    }
                }
            }
        }
        return response()->json([
            'success' => true,
            'message' => " regulization applied succesfully",
            'status' => $leave_status->status,
            'date' => $from_date
        ]);
    }


    public function approve(Request $request)
    {
        $user_id = $request->input('user_id');
        $reg_date = $request->input('date');

        $attendance_data = Attendence::where('user_id', $user_id)->where('date', $reg_date)->first();
        $attendance_data->attendance_status = "RA";
        $attendance_data->save();

        $status_update = Regulization::where('user_id', $user_id)->where('regulization_date', $reg_date)->first();
        $status_update->status = "approved";
        $status_update->save();
        return response()->json([
            'success' => true,
            'message' => " regulization applied succesfully",
            'regulization_date' => $reg_date
        ]);
    }

    public function cancel(Request $request)
    {
        $id = $request->input('table_id');
        $type = $request->input('type');
        if ($type == "WFH") {
            $data = Workfromhome::where('id', $id)->first();
            $data->delete();
        }
        if ($type == "regulization") {
            $data = Regulization::where('id', $id)->first();
            $data->delete();
        } else {
            $data = Leave::where('id', $id)->first();
            $data->delete();
        }
        return response()->json(['success' => true, 'message' => 'Work from home request canceled successfully']);
    }
}
