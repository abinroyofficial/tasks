<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{

    public function create(): View
    {
        return view('auth.login');
    }


    public function store(LoginRequest $request): RedirectResponse
    {
        $email = request()->email;
        $user = User::where('email', $email)->first();
        if ($user) {
            $roles = $user->getRoleNames()->implode(', '); 
        }
        $request->authenticate();
        


        $request->session()->regenerate();
        
        if ($roles == "senior manager") {
            return redirect()->intended(route('manager-dashboard', absolute: false));
        }
        else if($roles == "super admin"){
            return redirect()->intended(route('superadmin-dashboard', absolute: false));
        }
        else if($roles == "manager"){
            
            return redirect()->intended(route('manager-dashboard', absolute: false));
        }
        else if($roles == "employ"){
            return redirect()->intended(route('dashboard', absolute: false));
        }

         else {
            return redirect()->intended(route('/', absolute: false));
        }
    }

   
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
