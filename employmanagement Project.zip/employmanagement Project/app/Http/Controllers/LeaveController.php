<?php

namespace App\Http\Controllers;

use App\Models\Leave;
use App\Models\Manager;
use App\Models\Regulization;
use App\Models\UserLeave;
use App\Models\Workfromhome;
use Carbon\Carbon;
use Illuminate\Http\Request;

class LeaveController extends Controller
{
    public function index($id)
    {

        $data = Manager::where('user_id', $id)->first();
        $leave_count =UserLeave::where('user_id',$data->user_id)->first();
        


        return view('leave.leave-request', compact('data','leave_count'));
    }


    public function store(Request $request)
    {


        $request->validate([
            'user_id' => 'required|exists:users,id',
            'supervisor' => 'required',
            'leave_type' => 'required|string',
            'from_date' => 'required|date',
            'to_date' => 'required|date',
            'session' => 'required|string',
            'reason' => 'required|string',
            'remarks' => 'nullable|string',
        ]);



        $fromDate = Carbon::parse($request->from_date);
        $toDate = Carbon::parse($request->to_date);




        if ($fromDate == $toDate) {

            if ($request->session == "HALF DAY") {

                $totalDays = 0.5;
            } else {
                $totalDays = 1.0;
            }
        } else {
            $totalDays = $fromDate->diffInDays($toDate) + 1;
        }
        





        Leave::create([
            'user_id' => $request->user_id,
            'supervisor' => $request->supervisor,
            'apply_date' => $request->date,
            'type' => $request->leave_type,
            'from_date' => $request->from_date,
            'to_date' => $request->to_date,
            'session' => $request->session,
            'total' => $totalDays,
            'reason' => $request->reason,
            'remarks' => $request->remarks,

        ]);
        return redirect()->route('show-request', ['id' => $request->user_id]);
    }
    public function show($id)
    {

        $data = Leave::where('user_id', $id)->orderBy('created_at', 'desc')->get();
        $data2 = Workfromhome::where('user_id', $id)->orderBy('created_at', 'desc')->get();
        $data3 = Regulization::where('user_id', $id)->orderBy('created_at', 'desc')->get();

        return view('leave.view-request', compact('data', 'data2', 'data3'));
    }
}
